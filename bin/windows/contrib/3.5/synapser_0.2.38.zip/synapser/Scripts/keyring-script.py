#!C:\bin\R\bin\x64\Rscript.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'keyring==12.2.1','console_scripts','keyring'
__requires__ = 'keyring==12.2.1'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('keyring==12.2.1', 'console_scripts', 'keyring')()
    )
