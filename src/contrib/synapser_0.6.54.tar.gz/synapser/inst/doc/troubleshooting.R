## ----eval = F------------------------------------------------------------
#  > library(synapser)
#  
#  Loading required package: PythonEmbedInR
#  
#  Error: package or namespace load failed for ‘PythonEmbedInR’:
#  
#  .onLoad failed in loadNamespace() for 'PythonEmbedInR', details:
#  
#    call: library.dynam.unload("PythonEmbedInR", packageRootDir)
#  
#    error: DLL ‘PythonEmbedInR.dll’ was not loaded
#  
#  Error: package ‘PythonEmbedInR’ could not be loaded

## ----eval = F------------------------------------------------------------
#  > .libPaths()
#  [1] "\\\\samba-xxx/home/<your_home_dir>/Documents/R/win-library/3.4" "\\\\samba-xxx/home/<your_home_dir>/Documents/R/R-3.4.4/library"

## ----eval = F------------------------------------------------------------
#  > .libPaths("H:\\Documents\\R\\win-library\\3.4")
#  > .libPaths()
#  [1] "H:/Documents/R/win-library/3.4" "\\\\samba-xxxo/home/<your_home_dir>/Documents/R/R-3.4.4/library"
#  

